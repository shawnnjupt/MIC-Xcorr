/*
 * *****************************************************************************************
 *
 * 		Copyright (C) 2014-2020 Gowin Semiconductor Technology Co.,Ltd.
 *
 * @file		open_ahb.h
 * @author		Embedded Development Team
 * @version		V1.2
 * @date		2020-6-30 09:00:00
 * @brief		Open AHB definition
 ******************************************************************************************
 */

#ifndef __OPEN_AHB_H
#define __OPEN_AHB_H

/* Includes --------------------------------------------------------------------- */
#include "picorv32.h"

/* Open AHB Register Definitions --------------------------------------------------------------------- */
typedef struct {
	__IO unsigned int REG0;  //0x00
	__IO unsigned int REG1;  //0x04
} AHBREGDEMO_RegDef;

/* Address Definitions --------------------------------------------------------------------- */
#define AHBREGDEMO_BASE         _IO_(0x80000000)

#define PICO_AHBREGDEMO        ((AHBREGDEMO_RegDef  *)    AHBREGDEMO_BASE )

#endif
