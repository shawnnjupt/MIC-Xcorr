
#include "uart_printf.h"


void PrintFloat(char sentence[],float value)
{
    int tmp,tmp1,tmp2;
    if(value>=0)
    {
    tmp = (int)value;
    tmp1=(int)((value-tmp)*10)%10;
    tmp2=(int)((value-tmp)*100)%10;
    printf("%s=%d.%d%d\r\n",sentence,tmp,tmp1,tmp2);
    }
    else
    {
    	value=-1*value;
        tmp = (int)value;
        tmp1=(int)((value-tmp)*10)%10;
        tmp2=(int)((value-tmp)*100)%10;
        printf("%s=-%d.%d%d\r\n",sentence,tmp,tmp1,tmp2);

    }
}
