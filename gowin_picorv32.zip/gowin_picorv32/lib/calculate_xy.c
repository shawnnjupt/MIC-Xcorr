/*
 * calculate_xy.c
 *
 *  Created on: 2022年11月3日
 *      Author: Lenovo
 */

#include "calculate_xy.h"

//int mic1_place;
//int mic2_place;

//float source_x;
//float source_y;

#define vs_div_sample 0.32237f
#define onedivtwoplusegthree 0.288675f


float calculatex(uint32_t mic_1, uint32_t mic_2)
{


	int mic1_place;
	int mic2_place;
	int mic_place;

    if (mic_1 > 30)
    {
        mic1_place =mic_1-30;
    }else
    {
    	mic1_place=-1*mic_1;
    }
    if (mic_2 > 30)
    {
        mic2_place = mic_2 -30;
    }else
    {
    	mic2_place=-1*mic_2;
    }

    mic_place=(mic1_place+mic2_place)/2;

printf("mic1_place=%d\r\n",mic1_place);
printf("mic2_place=%d\r\n",mic2_place);
printf("micx_place=%d\r\n",mic_place);


return 0;
}

float calculatey(uint32_t mic_1, uint32_t mic_2)
{


	int mic1_place;
	int mic2_place;
	int mic_place;
    if (mic_1 > 30)
    {
        mic1_place =mic_1-30;
    }else
    {
    	mic1_place=-1*mic_1;
    }
    if (mic_2 > 30)
    {
        mic2_place = mic_2 -30;
    }else
    {
    	mic2_place=-1*mic_2;
    }

    mic_place=(mic1_place+mic2_place)/2;

printf("mic3_place=%d\r\n",mic1_place);
printf("mic4_place=%d\r\n",mic2_place);
printf("micy_place=%d\r\n",mic_place);


return 0;
}


float calculatez(uint32_t mic_1)
{


	int mic1_place;

    if (mic_1 > 30)
    {
        mic1_place =mic_1-30;
    }else
    {
    	mic1_place=-1*mic_1;
    }



printf("micz_place=%d\r\n",mic1_place);


return 0;
}


