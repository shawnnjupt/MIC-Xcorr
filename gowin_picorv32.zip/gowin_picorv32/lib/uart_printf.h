/*
 * uart_printf.h
 *
 *  Created on: 2022年11月3日
 *      Author: Lenovo
 */

#ifndef LIB_UART_PRINTF_H_
#define LIB_UART_PRINTF_H_

#include <stdio.h>
#include <stdarg.h>
#include "wbuart.h"

#ifdef USE_WBUART
#define get_char()   wbuart_getc()
#define put_char(c)  wbuart_putc(c)
#else
#define get_char()   uart_getchar()
#define put_char(c)  uart_putchar(c)
#endif


void PrintFloat(char sentence[],float value);

//int UART_printf(const char *fmt, ...);


#endif /* LIB_UART_PRINTF_H_ */
