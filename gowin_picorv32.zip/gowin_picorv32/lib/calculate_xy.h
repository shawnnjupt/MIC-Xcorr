/*
 * calculate_xy.h
 *
 *  Created on: 2022年11月3日
 *      Author: Lenovo
 */

#ifndef LIB_CALCULATE_XY_H_
#define LIB_CALCULATE_XY_H_



#include "uart_printf.h"
#include "math.h"


float calculatey(uint32_t mic_1, uint32_t mic_2);
float calculatex(uint32_t mic_1, uint32_t mic_2);
float calculatez(uint32_t mic_1);

#endif /* LIB_CALCULATE_XY_H_ */
